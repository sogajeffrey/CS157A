<?php
$conn =mysql_connect("jeffreysu.ddns.net:3306","root","secret123");
mysql_select_db("codemonkeys",$conn);
?>
