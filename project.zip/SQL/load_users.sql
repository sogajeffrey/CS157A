INSERT INTO `userinfo` (`uID`, `password`, `name`, `age`, `email`, `ssn`, `phoneNumber`, `type`) VALUES
('customer1', 'customer1123', 'Customer One', 27, 'customer1@monkeybank.com', '111-11-1111', '111-111-1111', 'Customer'),
('customer2', 'customer2123', 'Customer Two', 23, 'customer2@monkeybank.com', '222-22-2222', '222-222-2222', 'Customer'),
('manager1', 'manager1321', 'Manager One', 21, 'manager1@monkeybank.com', '333-33-3333', '333-333-3333', 'Manager'),
('manager4', 'manager4321', 'Manager Four', 45, 'manager4@monkeybank.com', '444-44-4444', '444-444-4444', 'Manager'),
('manager3', 'manager3321', 'Manager Three', 35, 'manager3@monkeybank.com', '555-55-5555', '555-555-5555', 'Manager'),
('customer3', 'customer3123', 'Customer Three', 50, 'customer3@monkeybank.com', '666-66-6666', '666-666-6666', 'Customer'),
('customer4', 'customer4123', 'Customer Four', 30, 'customer4@monkeybank.com', '777-77-7777', '777-777-7777', 'Customer'),
('customer5', 'customer5123', 'Customer Five', 26, 'customer5@monkeybank.com', '888-88-8888', '888-888-8888', 'Customer'),
('customer6', 'customer6123', 'Customer Six', 65, 'customer6@monkeybank.com', '999-99-9999', '999-999-9999', 'Customer'),
('customer7', 'customer7123', 'Customer Seven', 32, 'customer7@monkeybank.com', '111-22-1111', '111-222-1111', 'Customer'),
('customer8', 'customer8123', 'Customer Eight', 18, 'customer8@monkeybank.com', '222-33-2222', '222-333-2222', 'Customer'),
('Customer9', 'customer9123', 'Customer Nine', 47, 'customer9@monkeybank.com', '333-44-3333', '333-444-3333', 'Customer');